#!/bin/bash

echo "1. Affichez le nombre d'attributs par document ainsi que l'attribut name. Combien y a-t-il d'attribut par document ?"
cat people.json | jq '.[] | {count: length}' >> exam_ELOUAHIDI/exam_jq/res_jq.txt
cat people.json | jq '.[] | .name' >> exam_ELOUAHIDI/exam_jq/res_jq.txt
echo "Commande : cat people.json | jq '.[] | {count: length}' >> exam_ELOUAHIDI/exam_jq/res_jq.txt"
echo "Commande : cat people.json | jq '.[] | .name' >> exam_ELOUAHIDI/exam_jq/res_jq.txt"
echo "Réponse : réponse de la question 1 si demandé : il y a 17 attributs par document et "
echo -e "\n---------------------------------\n"
#
#
echo "2. Combien y a-t-il de valeur "unknown" pour l'attribut "birth_year" ?"
#<commande pour répondre>
echo "Commande : <commande pour répondre>"
echo "Réponse : réponse de la question n si demandé"
echo -e "\n---------------------------------\n"
#
#
echo "3. Affichez la date de création de chaque personnage et son nom."
#<commande pour répondre>
echo "Commande : <commande pour répondre>"
echo "Réponse : réponse de la question n si demandé"
echo -e "\n---------------------------------\n"
#
#
echo "4. Certains personnages sont nés en même temps. Retrouvez toutes les pairs d'ids (2 ids) des personnages nés en même temps."
#<commande pour répondre>
echo "Commande : <commande pour répondre>"
echo "Réponse : réponse de la question n si demandé"
echo -e "\n---------------------------------\n"
#
#
echo "5. Renvoyez le numéro du premier film dans lequel chaque personnage a été vu suivi du nom du personnage."
#<commande pour répondre>
echo "Commande : <commande pour répondre>"
echo "Réponse : réponse de la question n si demandé"
echo -e "\n---------------------------------\n"
