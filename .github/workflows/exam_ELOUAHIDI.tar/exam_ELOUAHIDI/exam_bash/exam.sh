#!/bin/bash
# lancement de api pour le faire tourner sous localhost
/home/ubuntu/api &
# récuperation de la date de traitement
function recup_valeur () {
  curl "http://0.0.0.0:5000/$1"
}
# Information de la date de traitement
echo "$(date)" >> exam_ELOUAHIDI/exam_bash/sales.txt
# Boucle  de récupération des valeurs de carte graphique
for i in rtx3060 rtx3070 rtx3080 rtx3090 rx6700
  do
  nb_cartes=$(recup_valeur $i);
  echo "$i : $nb_cartes" >> exam_ELOUAHIDI/exam_bash/sales.txt 
  done
